package adventure.game;

import adventure.game.Player;
import adventure.location.Location;
import adventure.location.Facility;
import adventure.location.FunRide;

import java.io.PrintStream;
import java.util.Scanner;

/*
 * OOP - WS1819 - SBL 1
 * Vorname Nachname (Matrikelnr.)
 * Vorname Nachname (Matrikelnr.)
 */

public class Game {
    public static Scanner scanner = new Scanner(System.in);

    public static void main(String[] argv) {
        // Create Locations
        FunRide rollerCoaster = new FunRide("Roller Coaster", 2.5, 5);
        Facility restroom = new Facility("Restroom", 0.5, 1);
        FunRide bumperCar = new FunRide("Bumper Car", 1, 2);
        Facility kiosk = new Facility("Kiosk", 2, 5);
        FunRide wildWaterChannel = new FunRide("Wild-Water Channel", 2.5, 5);
        Facility restaurant = new Facility("Restaurant", 10, 20);
        FunRide carousel = new FunRide("Carousel", 1, 2);
        FunRide freefallTower = new FunRide("Freefall Tower", 1, 2);
        Location entrance = new Location("Entrance");
        Location parkingLot = new Location("Parking Lot");

        // Create Paths
        rollerCoaster.createPath("up", restroom);
        restroom.createPath("left", bumperCar);
        bumperCar.createPath("down", kiosk);
        bumperCar.createPath("left", wildWaterChannel);
        wildWaterChannel.createPath("down", restaurant);
        restaurant.createPath("down", carousel);
        kiosk.createPath("left", carousel);
        restaurant.createPath("left", freefallTower);
        freefallTower.createPath("down", entrance);
        carousel.createPath("left", entrance);
        entrance.createPath("down", parkingLot);

        /*
         * TODO
         */
        //Create Player with Starting position "rollerCoaster"
        Player playerOne = new Player(rollerCoaster);

        //Game Begins
        //Prologue

        System.out.println("You’re in a theme park, it’s getting dark.");
        System.out.println("You want to go to your car.");
        System.out.println("On the way there you want to have as much fun as possible.");
        System.out.printf("But you have only limited energy and money left.%n%n");


        //Show Player status
        System.out.println(playerOne.toString());


        //Start Rounds
        while (true) {

            //Check if player has lost the game
            if (playerOne.getEnergy() < 0 && !playerOne.getCurrentLocation().equals(parkingLot)) {
                char euroSign = '\u20ac';
                System.out.printf("Game over. You collapse exhausted and the park inspector must carry you\n" +
                        "out of the park.\n" +
                        "You lose all your fun points! You have %d %c.\n", playerOne.getFunPoints(), euroSign);
                playerOne.gameOver(parkingLot); break;
            }

            //Check if player has won the game
            if (playerOne.getCurrentLocation().equals(parkingLot)) {        //getCurrentLocation in Player class
                char euroSign = '\u20ac';
                System.out.printf("You are here now: Parking lot\n" +
                        "Congratulations, you made it. You have collected %d fun points and have\n" +
                        "%4.2f .\n", playerOne.getFunPoints(), playerOne.getMoney(), euroSign );
                break;
            }


            System.out.print(">: ");
            String inputDirection = scanner.next().toLowerCase();

            /*
            Check whether input direction is valid and then do walk(inputDirection) or stay     //playerOne.walk(inputDirection) works
            I just couldn't figure out how to check yet
             */
        }

    }
}
